import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

public class Client {
	public static void main(String[]args) throws IOException {  
	
		String hostName = args[0];
		int portNumber = Integer.parseInt(args[1]);
		
		//connect to a socket
		try(
			Socket clientSocket = new Socket(hostName, portNumber);
			//get the output stream
			PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
			//imput stream
			BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
			//get the request from the user
			BufferedReader request = new BufferedReader(new InputStreamReader(System.in));
				){
			
			String input;
			String response;
			//array to hold the packets the client receives from the server
			ArrayList<String> arrayPackets = new ArrayList<String>();
			
			int number;
			String place;
			//true as long as client is missing packets
			boolean missing = true;
			
			//for loop to initialize the arrayPackets
			for (int i = 0; i < 26; i++) {
				arrayPackets.add("empty");
			}
		
			out.println(request.readLine());
			//continues to request packets and receive responses from the server as long as there are missing packets
			while(missing) {
				do {
					response = in.readLine();
					System.out.println("Server Responds: " + response);
					//parse the string to get the spot
					if ((!response.equals("all sent")) && !response.equals("26")) {
						//gets the first two characters of the string which serve as the index of the packet
						place = response.substring(0,2);
						//remove any white spaces (if the index is a single number)
						place = place.trim();
						number = Integer.parseInt(place);
						response = response.substring(2);	
						//add to the arraylist in the right order
						arrayPackets.set((number), response); 
					}	
				}while((!response.equals("all sent")));
				
			//put the ones that didnt come through into a arraylist6
				ArrayList<Integer> missingPackets = new ArrayList<Integer>();
			for (int i = 0; i < 26; i++) {
				String currentPacket = arrayPackets.get(i);
				if(currentPacket.equals("empty")) {
					missingPackets.add(i);
				}
			}
			
			//sets missing bases on whether there are still missing packets
			if(missingPackets.size() > 0) {
				missing = true;
			}
			else {
				missing = false;
				out.println("finished");
			}
			
			if (missing) {
				//send the array to the server loop through and send each thing
				for (int i = 0; i < missingPackets.size(); i++ ) {
					System.out.println("Sending Missing Packet " + missingPackets.get(i));
					out.println(missingPackets.get(i));
					}
				out.println("done");
			}
			else { 
				in.readLine();
				response = in.readLine();
					
				response = response.substring(2);
				
				//add to the arraylist in the right order
				arrayPackets.add(response); 
				for (int i = 0; i < 27; i++) {
					System.out.print(arrayPackets.get(i));
				}
			}
	
		}
		}
			
			//catch clause
			catch (UnknownHostException e) {
				System.out.println("Unrecognized host " + hostName);
				System.exit(1);
			}
			catch (IOException e) {
				System.out.println("I/O for connection " + hostName + " not found.");
				System.exit(1);
			}
	
		
		}
}

