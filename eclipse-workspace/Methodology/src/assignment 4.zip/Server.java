import java.io.*;
import java.net.*;
import java.util.Random;
import java.util.ArrayList;

public class Server  {
	public static void main(String[]args) throws IOException  {
		//port number
		int portNumber = Integer.parseInt(args[0]);
		
		//create the packets
		String one = "0 Oh say can ";
		String two = "1 you see ";
		String three = "2 by the dawn ";
		String four = "3 early light ";
		String five =  "4 what so proudly ";
	    String six = "5 we hailed ";
	    String seven = "6 at the twilight's last ";
		String eight = "7 gleaming? Whose broad stripes ";
		String nine=  "8 and bright stars ";
		String ten =  "9 Through the perilous fight ";
		String eleven = "10O'er the ramparts ";
		String twelve =  "11we watched ";
		String thirteen = "12were so gallantly ";
		String fourteen =  "13streaming? And the ";
		String fifteen =  "14rockets' red glare ";
		String sixteen =  "15the bombs ";
		String seventeen = "16bursting in air ";
		String eighteen = "17gave proof through ";
		String nineteen =  "18the night that ";
		String twenty =  "19our flag was still ";
		String twentyOne= "20there O say";
		String twentyTwo =  "21does that star ";
		String twentyThree = "22spangled banner yet ";
		String twentyFour = "23wave O'er the land ";
		String twentyFive =  "24of the free ";
		String twentySix = "25and the home of ";
		String twentySeven = "26the brave!!";
		//put packets in array
		String[] packetArray= {one, two, three, four, five, six, seven, eight, nine, ten,
									eleven, twelve, thirteen, fourteen, fifteen, sixteen,
									seventeen, eighteen, nineteen, twenty, twentyOne, twentyTwo,
									twentyThree, twentyFour, twentyFive, twentySix, twentySeven};
		
	
		//connect to a socket 
		try (
				ServerSocket server = new ServerSocket(Integer.parseInt(args[0]));
				Socket client = server.accept();
				PrintWriter response1 = new PrintWriter(client.getOutputStream(), true);
				BufferedReader request1 = new BufferedReader(new InputStreamReader(client.getInputStream()));				
				){
			
			String request = request1.readLine();
			Random rand = new Random();
			ArrayList<Integer> arrayMissing = new ArrayList<Integer>();
			
			
			
				//int var = 0;
				System.out.println(request + " recieved");
					//get one of the package to send
					//arraylist to keep track of whether or not the packet was added
					ArrayList<Integer> wasAdded = new ArrayList<Integer>();
					//for loop to loop through the array to send them in a random order
					for (int i = 0; i < (packetArray.length - 1); i++) {
						//get a random number 
						int random = rand.nextInt(0 + 26);
						boolean inList = wasAdded.contains(random);
						if (!inList) {
							//drop some of them 
							int value = rand.nextInt(1 + 101);
							wasAdded.add(random);
							if (value >= 20) {
								// send the string over
								String response = packetArray[random];
								System.out.println("Sending " + response);
								response1.println(response); //sending back to the client
								
							}
						}
					}
					response1.println("all sent");

					request = request1.readLine();
				
			//loops while the client is still making requests
				while(!(request.equals("finished"))) {
					do{
						if(!request.equals("done")) {
						System.out.println("Received " + request);
						}
						if (!(request.equals("done")) && !(request.equals("finished"))) {
						arrayMissing.add(Integer.parseInt(request));
						}
					}while(!(request = request1.readLine()).equals("done") && !(request.equals("finished")));
					
					
					do {
						//add the values recieved to a new list to send them to the client
					wasAdded = new ArrayList<Integer>();
					for (int i = 0; i < arrayMissing.size(); i++) {
						//get a random number 
						int random = rand.nextInt(0 + arrayMissing.size());
						boolean inList = wasAdded.contains(random);
						if (!inList) {
							//drop some of them 
							int value = rand.nextInt(1 + 101);
							wasAdded.add(random);
							String response = packetArray[arrayMissing.get(random)];
							arrayMissing.remove(random);
							if (value >= 20) {
								// send the string over
								System.out.println("Sending " + response);
								response1.println(response); //sending back to the client
								
								
							}
						}
					}

				//sends all sent when it is done looping through the missing packets and sending them with 80% probability 
				}while(!(arrayMissing.isEmpty()));
					response1.println("all sent");
				}
				System.out.println("Sending 26");
					response1.println(packetArray[26]);
					}
				catch (IOException e) {
				System.out.println(
						"Exception caught when trying to listen on port " + portNumber + " or listening for a connection");
				System.out.println(e.getMessage());
			}
			
		
	}

}